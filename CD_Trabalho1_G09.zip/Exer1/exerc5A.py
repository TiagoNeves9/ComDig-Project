def prog(N, u, r):
    i = 0
    while i < N:
        print((u + i) * r)
        i += 1
